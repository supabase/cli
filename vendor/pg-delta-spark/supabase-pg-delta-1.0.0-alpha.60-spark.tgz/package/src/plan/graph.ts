/**
 * One graph, one deterministic sort (target-architecture §3.6).
 * Heap-based Kahn; a cycle throws with the full path — there is no repair
 * subsystem and never will be (guardrail 4).
 */

class MinHeap {
  #items: number[] = [];
  constructor(private readonly keyOf: (i: number) => string) {}

  get size(): number {
    return this.#items.length;
  }

  push(item: number): void {
    this.#items.push(item);
    let i = this.#items.length - 1;
    while (i > 0) {
      const parent = (i - 1) >> 1;
      if (
        this.keyOf(this.#items[parent] as number) <=
        this.keyOf(this.#items[i] as number)
      )
        break;
      [this.#items[parent], this.#items[i]] = [
        this.#items[i] as number,
        this.#items[parent] as number,
      ];
      i = parent;
    }
  }

  pop(): number {
    const top = this.#items[0] as number;
    const last = this.#items.pop() as number;
    if (this.#items.length > 0) {
      this.#items[0] = last;
      let i = 0;
      for (;;) {
        const l = 2 * i + 1;
        const r = l + 1;
        let smallest = i;
        if (
          l < this.#items.length &&
          this.keyOf(this.#items[l] as number) <
            this.keyOf(this.#items[smallest] as number)
        )
          smallest = l;
        if (
          r < this.#items.length &&
          this.keyOf(this.#items[r] as number) <
            this.keyOf(this.#items[smallest] as number)
        )
          smallest = r;
        if (smallest === i) break;
        [this.#items[smallest], this.#items[i]] = [
          this.#items[i] as number,
          this.#items[smallest] as number,
        ];
        i = smallest;
      }
    }
    return top;
  }
}

export function topoSort(
  nodeCount: number,
  edges: Array<[before: number, after: number]>,
  tieKeyOf: (node: number) => string,
  describe: (node: number) => string,
): number[] {
  const adjacency: number[][] = Array.from({ length: nodeCount }, () => []);
  const indegree = Array.from({ length: nodeCount }, () => 0);
  const seen = new Set<string>();
  for (const [u, v] of edges) {
    if (u === v) continue;
    const key = `${u}>${v}`;
    if (seen.has(key)) continue;
    seen.add(key);
    (adjacency[u] as number[]).push(v);
    indegree[v] = (indegree[v] as number) + 1;
  }

  // `keyOf` is consulted inside EVERY heap sift comparison, so the heap asks for
  // O(n log n) keys over only `nodeCount` distinct nodes. The caller's key is a
  // pure function of the node index (see `actionTieKey` — it reads the fixed
  // action list, rule resolver, subject-key override and evaluator set), so
  // memoizing per index is transparent: the heap sees exactly the same keys, and
  // therefore produces exactly the same order.
  const tieKeys = Array.from<string | undefined>({ length: nodeCount });
  const memoizedTieKeyOf = (node: number): string => {
    const cached = tieKeys[node];
    if (cached !== undefined) return cached;
    const key = tieKeyOf(node);
    tieKeys[node] = key;
    return key;
  };

  const heap = new MinHeap(memoizedTieKeyOf);
  for (let i = 0; i < nodeCount; i++) if (indegree[i] === 0) heap.push(i);

  const order: number[] = [];
  while (heap.size > 0) {
    const node = heap.pop();
    order.push(node);
    for (const next of adjacency[node] as number[]) {
      indegree[next] = (indegree[next] as number) - 1;
      if (indegree[next] === 0) heap.push(next);
    }
  }

  if (order.length !== nodeCount) {
    // a cycle is a RULE BUG: report the cycle path, never repair (guardrail 4)
    const inCycle = new Set<number>();
    for (let i = 0; i < nodeCount; i++)
      if ((indegree[i] as number) > 0) inCycle.add(i);
    const cyclePath = [...inCycle].map(describe).join("\n  ");
    throw new Error(
      `dependency cycle among ${inCycle.size} actions — this is a rule/emission bug, fix the rule (guardrail 4):\n  ${cyclePath}`,
    );
  }
  return order;
}

/** Tarjan SCC (iterative — no recursion-depth ceiling on large schemas):
 *  node → component index, over `adjacency` and every node it mentions. */
export function stronglyConnectedComponents(
  adjacency: ReadonlyMap<string, ReadonlySet<string>>,
): Map<string, number> {
  const sccOf = new Map<string, number>();
  const index = new Map<string, number>();
  const low = new Map<string, number>();
  const onStack = new Set<string>();
  const stack: string[] = [];
  let counter = 0;
  let sccCount = 0;
  const nodes = new Set<string>(adjacency.keys());
  for (const targets of adjacency.values()) {
    for (const t of targets) nodes.add(t);
  }
  interface Frame {
    node: string;
    neighbors: string[];
    i: number;
  }
  const visit = (frames: Frame[], node: string): void => {
    index.set(node, counter);
    low.set(node, counter);
    counter++;
    stack.push(node);
    onStack.add(node);
    frames.push({ node, neighbors: [...(adjacency.get(node) ?? [])], i: 0 });
  };
  for (const root of nodes) {
    if (index.has(root)) continue;
    const frames: Frame[] = [];
    visit(frames, root);
    while (frames.length > 0) {
      const frame = frames[frames.length - 1]!;
      if (frame.i < frame.neighbors.length) {
        const next = frame.neighbors[frame.i++]!;
        if (!index.has(next)) {
          visit(frames, next);
        } else if (onStack.has(next)) {
          low.set(frame.node, Math.min(low.get(frame.node)!, index.get(next)!));
        }
      } else {
        frames.pop();
        const parent = frames[frames.length - 1];
        if (parent !== undefined) {
          low.set(
            parent.node,
            Math.min(low.get(parent.node)!, low.get(frame.node)!),
          );
        }
        if (low.get(frame.node) === index.get(frame.node)) {
          let member: string;
          do {
            member = stack.pop()!;
            onStack.delete(member);
            sccOf.set(member, sccCount);
          } while (member !== frame.node);
          sccCount++;
        }
      }
    }
  }
  return sccOf;
}
