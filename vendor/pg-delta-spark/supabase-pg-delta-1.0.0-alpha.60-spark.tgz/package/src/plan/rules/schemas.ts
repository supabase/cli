/** Rule definitions for schemas and extensions. */
import type { StableId } from "../../core/stable-id.ts";
import { qid } from "../render.ts";
import type { KindRules } from "../rules.ts";
import { p, renameRule, str } from "./helpers.ts";

/**
 * Canonical `CREATE SCHEMA` rendering — the single source of truth shared by the
 * schema create rule (bare form) and the co-create ownership fold
 * (`internal.ts::foldCoCreateOwnership`), which appends `AUTHORIZATION` so a
 * freshly-created schema + its owner ALTER collapse into one statement. Keeping
 * both callers on this helper means the fold never reconstructs DDL by string
 * surgery — it renders the canonical form and compares.
 */
export function schemaCreateSql(
  schemaName: string,
  ownerRole?: string,
): string {
  const base = `CREATE SCHEMA ${qid(schemaName)}`;
  return ownerRole === undefined
    ? base
    : `${base} AUTHORIZATION ${qid(ownerRole)}`;
}

/** Extensions whose replace-for-relocation is never acceptable: dropping them
 *  cascades over user data columns (postgis: geometry/geography everywhere).
 *  Not generalized beyond this named set — PostGIS is the one extension where
 *  a "converging" drop+create nukes spatial data and still looks successful. */
const NEVER_REPLACE_FOR_RELOCATION = new Set(["postgis"]);

export const SCHEMA_WEIGHT = 1;

export const schemaRules: Record<string, KindRules> = {
  schema: {
    weight: SCHEMA_WEIGHT,
    defaclObjtype: "n", // ALTER DEFAULT PRIVILEGES … ON SCHEMAS
    rename: renameRule(
      (fact) => `ALTER SCHEMA ${qid((fact.id as { name: string }).name)}`,
    ),
    create: (fact) => [
      { sql: schemaCreateSql((fact.id as { name: string }).name) },
    ],
    drop: (fact) => ({
      sql: `DROP SCHEMA ${qid((fact.id as { name: string }).name)}`,
    }),
    ownerAlterPrefix: (fact) =>
      `ALTER SCHEMA ${qid((fact.id as { name: string }).name)}`,
    attributes: {},
  },

  extension: {
    weight: 2,
    // Whether to emit `SCHEMA <s>` is a PLAN-TIME property: the clause is valid
    // iff schema `s` EXISTS when CREATE EXTENSION runs — present on the target
    // (source view, incl. reference-only platform schemas such as Supabase's
    // `extensions`) or created by this plan (managed desired schema; `consumes`
    // orders CREATE SCHEMA first, and the clause keeps any load order of an
    // export convergent). Otherwise emit the bare form; built-in schemas
    // (pg_cron's pg_catalog) are never extracted and fall here too. A schema
    // the control file pins and the target already holds is bare too: Postgres
    // finds or creates it, while the clause would fail where `s` is merely
    // assumed (the export's pristine source seeds platform schemas such as
    // `pgmq` that a fresh database lacks).
    // See docs/architecture/managed-view-architecture.md.
    create: (fact, view, _params, sourceView) => {
      const schemaName = str(p(fact, "schema"));
      const schemaId: StableId = { kind: "schema", name: schemaName };
      const onTarget = sourceView?.get(schemaId) !== undefined;
      const createdByPlan =
        !onTarget &&
        view.get(schemaId) !== undefined &&
        !view.isReferenceOnly(schemaId);
      const name = qid((fact.id as { name: string }).name);
      if (!onTarget && !createdByPlan) {
        return [{ sql: `CREATE EXTENSION ${name}` }];
      }
      return [
        {
          sql:
            onTarget && p(fact, "_controlSchema") === schemaName
              ? `CREATE EXTENSION ${name}`
              : `CREATE EXTENSION ${name} SCHEMA ${qid(schemaName)}`,
          consumes: [schemaId],
        },
      ];
    },
    // DROP EXTENSION cascades to its member objects (pg_depend deptype 'e'), but
    // those members are projected out of the diff (kept reference-only), so no
    // other action raises the destructive flag for them. Derive it here from the
    // member closure: destructive iff the extension owns a DATA-BEARING persisted
    // relation (table / materialized view) — dropping it destroys user rows. An
    // extension whose members are only functions/types/operators/etc. drops
    // without data loss, so it stays non-destructive (matches the per-kind
    // convention: DROP TABLE is destructive, DROP FUNCTION is not). The proof
    // loop turns this into a verified claim; here it is only the reported hazard.
    // Reference-only members survive in the resolved view with their
    // `memberOfExtension` edges intact, so `incomingEdges` sees them.
    drop: (fact, view) => {
      const members = (view?.incomingEdges(fact.id) ?? [])
        .filter((edge) => edge.kind === "memberOfExtension")
        .map((edge) => edge.from);
      const destructive = members.some(
        (member) =>
          member.kind === "table" || member.kind === "materializedView",
      );
      return {
        sql: `DROP EXTENSION ${qid((fact.id as { name: string }).name)}`,
        ...(members.length > 0 ? { alsoDestroys: members } : {}),
        ...(destructive ? { dataLoss: "destructive" as const } : {}),
      };
    },
    attributes: {
      schema: {
        // consume the NEW schema so the relocation is ordered after its CREATE;
        // release the OLD schema so it runs before a same-plan DROP SCHEMA of
        // the old home (otherwise the drop can be sequenced first and fail).
        alter: (fact, from, to) => ({
          sql: `ALTER EXTENSION ${qid((fact.id as { name: string }).name)} SET SCHEMA ${qid(str(to))}`,
          consumes: [{ kind: "schema", name: str(to) }],
          releases: [{ kind: "schema", name: str(from) }],
        }),
        // A non-relocatable extension rejects SET SCHEMA, so relocating it must
        // be a drop + recreate in the new schema (its create rule emits the
        // `SCHEMA <s>` clause). The `_relocatable` flag is version-derived,
        // non-semantic metadata read only for this plan-time decision.
        //
        // Some of those rebuilds are never acceptable: dropping postgis
        // cascades over every geometry/geography column and spatial_ref_sys.
        // Refuse before replaceWhen would classify the fact as a replace —
        // a genuine DROP EXTENSION (extension absent on the desired side)
        // never reaches this predicate.
        replaceWhen: (from, to, fact) => {
          const name = (fact.id as { name: string }).name;
          if (NEVER_REPLACE_FOR_RELOCATION.has(name)) {
            const fromSchema = str(from);
            const toSchema = str(to);
            throw new Error(
              `plan: extension "${name}" cannot be relocated from schema "${fromSchema}" to "${toSchema}" after install. ` +
                `PostGIS cannot be relocated after install — align the schema declaration to the installed location ("${fromSchema}") instead.`,
            );
          }
          return p(fact, "_relocatable") === false;
        },
      },
    },
  },
};
