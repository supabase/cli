/**
 * Planner phase 3 — ActionEmitter (target-architecture §3.4–3.5).
 *
 * Turns the projected change set + replacement expansion into the atomic action
 * list, with its OWN producer/destroyer/fold bookkeeping (local to this phase —
 * the cohesive emission algorithm the planner once inlined). Emits, in order:
 * rename actions, creates (parents first), default-privilege hygiene, drops,
 * replaces (drop + recreate), in-place alters, and owner-edge ALTERs. Enforces
 * the create-produces-its-fact invariant at the phase boundary.
 */
import type { Delta } from "../../core/diff.ts";
import type { Fact, FactBase } from "../../core/fact.ts";
import { encodeId, type StableId } from "../../core/stable-id.ts";
import {
  canSetOwner,
  type ApplierCapability,
} from "../../policy/capability.ts";
import {
  factMatches,
  isOverlayDefaultPrivilege,
  type AssumedDefaultGrant,
  type SerializeRule,
} from "../../policy/policy.ts";
import { extensionMemberClosure } from "../../policy/view.ts";
import { lockClassFor } from "../locks.ts";
import type { Action } from "../plan.ts";
import { qid } from "../render.ts";
import { subtreeIds } from "../renames.ts";
import { cascadesToChildren, ruleFlag } from "../rule-flags.ts";
import {
  type ActionSpec,
  type FoldHint,
  type PlanParams,
  type RulesForId,
} from "../rules.ts";
import {
  columnAclIdsFor,
  defaultPrivilegeCreateActions,
  identitySequenceId,
  renderRevokeAllSql,
} from "../rules/helpers.ts";
import type { AcceptedRename } from "./change-set.ts";

export interface ActionEmitterInput {
  /** resolved source / desired views + the projected plan target */
  source: FactBase;
  desired: FactBase;
  projectedDesired: FactBase;
  /** canonical add/remove worklists + grouped set-deltas */
  removed: ReadonlyMap<string, Fact>;
  added: ReadonlyMap<string, Fact>;
  setsByFact: ReadonlyMap<string, Extract<Delta, { verb: "set" }>[]>;
  /** from ReplacementExpansion */
  replaceIds: ReadonlySet<string>;
  dropRootOf: ReadonlyMap<string, string>;
  /** from ChangeSet */
  acceptedRenames: readonly AcceptedRename[];
  deltas: readonly Delta[];
  /** serialize params + policy serialize rules */
  params: PlanParams;
  serializeRules: readonly SerializeRule[];
  capability: ApplierCapability | undefined;
  /** id-keyed rule resolver (schema kinds via the static RULES table,
   *  `extensionIntent` via the profile's intent rules) */
  rulesForId: RulesForId;
  /** Load-environment default grants to wipe on CREATE when the desired ACL
   *  has no matching fact. Empty → projected-ADP hygiene only. */
  assumedDefaultGrants: readonly AssumedDefaultGrant[];
  /** Overlay tuples forwarded via `plan({ assumedDefaultGrants })` (export).
   *  Policy-only overlay still drives hygiene; it must not inject ADP wipes
   *  into DB-to-DB plans whose source already is the live target. */
  overlayAdpWipes: readonly AssumedDefaultGrant[];
  /** Overlay grantees whose create-time REVOKE is legal on this apply target.
   *  Export fills every overlay grantee; policy-only only those present as
   *  role facts on the raw source extract. */
  overlayHygieneGrantees: ReadonlySet<string>;
  /** Implicit owner after database-scope projection prunes that edge.
   *  Projected-ADP hygiene matches `defaultPrivilege.role` against this when
   *  the object has no owner edge. */
  defaultOwner?: string;
}

export interface ActionEmitterOutput {
  actions: Action[];
  producerOf: Map<string, number>;
  destroyerOf: Map<string, number>;
  foldHints: Array<FoldHint | undefined>;
  acceptsFolds: boolean[];
  renameActionIndices: Set<number>;
  /** action index → encoded ids in its `destroys` that are side-effect wipes
   *  (rule-declared `implicitlyDestroys`), for the graph: reproduce edge only,
   *  no teardown edges. Transient, never persisted. */
  implicitDestroys: Map<number, Set<string>>;
}

/**
 * Emit the atomic action list from the change set + replacement expansion.
 * Behavior-preserving extraction of `plan()`'s emission block.
 */
export function emitActions(input: ActionEmitterInput): ActionEmitterOutput {
  const {
    source,
    desired,
    projectedDesired,
    removed,
    added,
    setsByFact,
    replaceIds,
    dropRootOf,
    acceptedRenames,
    deltas,
    params,
    serializeRules,
    capability,
    rulesForId,
    assumedDefaultGrants,
    overlayAdpWipes,
    overlayHygieneGrantees,
    defaultOwner,
  } = input;

  const actions: Action[] = [];
  const producerOf = new Map<string, number>();
  const destroyerOf = new Map<string, number>();
  // transient per-action compaction metadata (never enters the artifact)
  const foldHints: Array<FoldHint | undefined> = [];
  const acceptsFolds: boolean[] = [];

  // side-effect wipes per action (see ActionEmitterOutput.implicitDestroys)
  const implicitDestroys = new Map<number, Set<string>>();

  const pushAction = (
    verb: Action["verb"],
    spec: ActionSpec,
    opts: {
      produces?: StableId[];
      consumes?: StableId[];
      destroys?: StableId[];
      wipes?: StableId[];
    },
  ): number => {
    const index = actions.length;
    const produces = [...(opts.produces ?? []), ...(spec.alsoProduces ?? [])];
    const destroys = [...(opts.destroys ?? []), ...(spec.alsoDestroys ?? [])];
    const consumes = [...(opts.consumes ?? []), ...(spec.consumes ?? [])];
    const wipes = (opts.wipes ?? []).filter(
      (id) => !destroys.some((d) => encodeId(d) === encodeId(id)),
    );
    if (wipes.length > 0) {
      implicitDestroys.set(index, new Set(wipes.map(encodeId)));
      destroys.push(...wipes);
    }
    const subjectKind = (produces[0] ?? destroys[0] ?? consumes[0])?.kind;
    actions.push({
      sql: spec.sql,
      verb,
      produces,
      consumes,
      destroys,
      releases: spec.releases ?? [],
      transactionality: spec.transactionality ?? "transactional",
      lockClass:
        spec.lockClass ??
        (subjectKind === undefined ? "none" : lockClassFor(subjectKind, verb)),
      newSegmentBefore: false,
      dataLoss: spec.dataLoss ?? "none",
      rewriteRisk: spec.rewriteRisk ?? false,
    });
    foldHints[index] = spec.compaction;
    acceptsFolds[index] = spec.acceptsColumnFolds ?? false;
    for (const id of produces) {
      const key = encodeId(id);
      if (!producerOf.has(key)) producerOf.set(key, index);
    }
    // a wipe is not the id's destroyer: its own drop (if any) stays the one
    // consumers / releasers / child teardown order against
    const wipeKeys = implicitDestroys.get(index);
    for (const id of destroys) {
      const key = encodeId(id);
      if (wipeKeys?.has(key) === true) continue;
      destroyerOf.set(key, index);
    }
    return index;
  };

  const paramsCache = new Map<string, PlanParams>();
  const paramsFor = (fact: Fact): PlanParams => {
    if (serializeRules.length === 0) return params;
    const key = encodeId(fact.id);
    const cached = paramsCache.get(key);
    if (cached !== undefined) return cached;
    let merged = params;
    for (const rule of serializeRules) {
      if (factMatches(rule.match, fact, desired)) {
        merged = { ...rule.params, ...params };
        break;
      }
    }
    paramsCache.set(key, merged);
    return merged;
  };

  const isRemovedId = (id: StableId): boolean =>
    removed.has(encodeId(id)) || replaceIds.has(encodeId(id));

  // Invert dropRootRedirect once. A per-DROP scan of dropRootOf is
  // O(roots × |facts|); a large remove would re-walk the same map on every
  // DROP. Direct match only — walking dropRootOf would list attached child
  // indexes on DROP TABLE when their parent index folded into the table
  // (inherit vs child-teardown cycle).
  const redirectedOntoByRoot = new Map<string, StableId[]>();
  for (const foldedKey of dropRootOf.keys()) {
    const folded = source.getByEncoded(foldedKey);
    if (folded === undefined) continue;
    const redirect = rulesForId(folded.id).dropRootRedirect?.(
      folded,
      isRemovedId,
    );
    if (redirect === undefined) continue;
    const rootKey = encodeId(redirect);
    const list = redirectedOntoByRoot.get(rootKey);
    if (list === undefined) redirectedOntoByRoot.set(rootKey, [folded.id]);
    else list.push(folded.id);
  }
  const redirectedOnto = (rootKey: string): readonly StableId[] =>
    redirectedOntoByRoot.get(rootKey) ?? [];

  // facts a statement of this fact's kind wipes as a side effect (rule-declared
  // `implicitlyDestroys`); attached to the producing create and to the drop as
  // `wipes`, so their re-creation is ordered after the wipe.
  const implicitlyDestroyed = (fact: Fact): StableId[] =>
    rulesForId(fact.id).implicitlyDestroys?.(fact, projectedDesired, source) ??
    [];

  const emitCreate = (fact: Fact, base: FactBase): void => {
    let specs = rulesForId(fact.id).create(fact, base, paramsFor(fact), source);
    // Overlay dest may hold a SUPERSET of this ADP. GRANT is additive — wipe first.
    if (
      ((fact.payload["privileges"] as string[] | undefined) ?? []).length > 0 &&
      isOverlayDefaultPrivilege(overlayAdpWipes, fact.id)
    ) {
      specs = [
        ...defaultPrivilegeCreateActions({
          id: fact.id,
          payload: { privileges: [], grantable: [] },
        }),
        ...specs,
      ];
    }
    const wiped = implicitlyDestroyed(fact);
    specs.forEach((spec, i) => {
      pushAction("create", spec, {
        produces: i === 0 ? [fact.id] : [],
        consumes: [
          ...(i === 0 ? [] : [fact.id]),
          ...(fact.parent !== undefined ? [fact.parent] : []),
        ],
        wipes: i === 0 ? wiped : [],
      });
    });
  };

  // renames: one action renames the whole subtree — produces every new id,
  // destroys every old id; dependents order against those sets. Tracked so
  // buildActionGraph can treat them as identity-only: a rename does NOT
  // establish or tear down the owner edge (PostgreSQL preserves the owner across
  // RENAME), so owner edges on the renamed subtree must not drive graph ordering
  // through the rename (review P1 #2: rename/rename cycle).
  const renameActionIndices = new Set<number>();
  for (const { from, to, sourceSubtree, desiredSubtree } of acceptedRenames) {
    const rename = rulesForId(from.id).rename;
    if (rename === undefined) {
      throw new Error(
        `rename: kind '${from.id.kind}' matched as candidate but has no rename rule`,
      );
    }
    renameActionIndices.add(
      pushAction("alter", rename(from, to.id), {
        produces: desiredSubtree,
        destroys: sourceSubtree,
        consumes: to.parent !== undefined ? [to.parent] : [],
      }),
    );
  }

  // Desired-side extension → member-keys index, computed lazily — only an
  // extension REPLACE needs it (see the satellite replay below). Inverted from
  // extensionMemberClosure so each replaced extension does ONE Map lookup
  // instead of scanning every member of every extension per replace key;
  // members keep the closure's iteration order, so emission order is unchanged.
  let desiredMembersByExtensionMemo: Map<string, string[]> | undefined;
  const desiredMembersByExtension = (): Map<string, string[]> => {
    if (desiredMembersByExtensionMemo === undefined) {
      desiredMembersByExtensionMemo = new Map();
      for (const [memberKey, exts] of extensionMemberClosure(
        projectedDesired,
      )) {
        for (const extKey of new Set(exts.map((ext) => encodeId(ext)))) {
          const members = desiredMembersByExtensionMemo.get(extKey);
          if (members === undefined) {
            desiredMembersByExtensionMemo.set(extKey, [memberKey]);
          } else {
            members.push(memberKey);
          }
        }
      }
    }
    return desiredMembersByExtensionMemo;
  };

  // replaces: drop old + create new (+ recreate unchanged descendants).
  // Emitted BEFORE the added-creates loop so a replaced parent's CREATE registers
  // its inlined delta-set children (publication members, etc.) in `producerOf`
  // first — the added loop's producerOf check then suppresses the redundant
  // standalone create of a child the replacement already materialized (a member
  // ADDed by CREATE … FOR TABLE must not also emit ALTER PUBLICATION ADD TABLE).
  // Emission order does not affect apply order (the action graph re-sorts).
  const recreatedByReplace = new Set<string>();
  // descendants a replaced ancestor's CREATE materialized via `alsoProduces`
  // (a partitioned parent's columns): no action of their own, but they are
  // still created on the target and take default-privilege hygiene. The
  // CREATE already renders their projected payload, so their attribute
  // alters are skipped too.
  const inlinedByReplace = new Set<string>();
  for (const key of replaceIds) {
    const oldFact = source.getByEncoded(key) as Fact;
    // the replacement is rendered from the PROJECTED plan target, so a filtered
    // attribute change or child fact is not baked into the recreated SQL (P1 #1)
    const newFact = projectedDesired.getByEncoded(key) as Fact;
    // The old subtree dies with the replace. A child folds into its parent's
    // DROP only when that parent's DROP CASCADES to it (DROP TABLE → its
    // columns); a child across a NON-cascading boundary (a foreign table or user
    // mapping under a server, whose DROP SERVER is RESTRICT) needs its OWN drop
    // action, which the graph's child-teardown rule orders before the parent's
    // drop. Without this the bare DROP SERVER fails on its surviving dependents.
    const emitReplaceDrop = (rootFact: Fact): void => {
      const rootKey = encodeId(rootFact.id);
      const destroys: StableId[] = [rootFact.id, ...redirectedOnto(rootKey)];
      const walk = (fact: Fact): void => {
        for (const child of source.childrenOf(fact.id)) {
          if (cascadesToChildren(fact.id.kind)) {
            destroys.push(child.id);
            walk(child);
          } else {
            emitReplaceDrop(child);
          }
        }
      };
      walk(rootFact);
      // A non-root (boundary) child drop must NOT consume its parent: the parent
      // is re-created in this same plan, so consuming it would order the child
      // drop AFTER the parent's re-create. Its ordering before the parent drop
      // comes from the child-teardown rule (source parent → parentDestroyer).
      const isRoot = encodeId(rootFact.id) === key;
      pushAction("drop", rulesForId(rootFact.id).drop(rootFact, source), {
        consumes:
          isRoot && rootFact.parent !== undefined ? [rootFact.parent] : [],
        destroys,
        wipes: implicitlyDestroyed(rootFact),
      });
    };
    // Attached child indexes fold into the parent-index replace via
    // dropRootRedirect. Skip this DROP (PG cascades it); still CREATE.
    const foldedInto = dropRootOf.get(key);
    if (foldedInto === undefined || foldedInto === key) {
      emitReplaceDrop(oldFact);
    }
    emitCreate(newFact, projectedDesired);
    // recreate surviving descendants from the PROJECTED plan target (satellites,
    // sub-facts). Descendants with their own attribute deltas are covered: the
    // create renders the projected payload, so their alters are skipped; a
    // descendant whose add was policy-filtered is absent and so not recreated.
    const recreate = (id: StableId): void => {
      for (const child of projectedDesired.childrenOf(id)) {
        const childKey = encodeId(child.id);
        if (added.has(childKey)) continue; // already created via add delta
        // already materialized by an ancestor's create via `alsoProduces`
        // (delta-set inlining — e.g. a validated CHECK inlined into CREATE
        // DOMAIN, a partitioned table's columns): don't recreate it as a
        // standalone action (which would duplicate it and fail apply), but still
        // descend for any non-inlined descendants. Mirrors the added-create loop.
        if (producerOf.has(childKey)) {
          inlinedByReplace.add(childKey);
          recreate(child.id);
          continue;
        }
        recreatedByReplace.add(childKey);
        emitCreate(child, projectedDesired);
        recreate(child.id);
      }
    };
    recreate(newFact.id);
    // A replaced EXTENSION re-materializes its members with installation
    // defaults. The members themselves are reference-only (never standalone
    // actions), but their desired-side SATELLITES (a user COMMENT/GRANT on a
    // member) die with the DROP — and when the customization is identical on
    // both sides there is no delta to re-emit it. Replay them from the
    // projected target; the member consume orders them after the re-CREATE.
    // (The closure maps members to their owning EXTENSIONS only, so a
    // non-extension replace key can never have members — skip the lookup.)
    if (oldFact.id.kind === "extension") {
      for (const memberKey of desiredMembersByExtension().get(key) ?? []) {
        const member = projectedDesired.getByEncoded(memberKey);
        if (!member) continue;
        for (const child of projectedDesired.childrenOf(member.id)) {
          if (ruleFlag(child.id.kind, "metadata") !== true) continue;
          const childKey = encodeId(child.id);
          if (added.has(childKey) || producerOf.has(childKey)) continue;
          recreatedByReplace.add(childKey);
          emitCreate(child, projectedDesired);
        }
      }
    }
  }

  // Overlay ADP wipes: export-only. The load dest can inject defaults the
  // pristine source never had; DB-to-DB source already is the live target.
  for (const tuple of overlayAdpWipes) {
    if (tuple.schema != null) {
      const schemaId: StableId = { kind: "schema", name: tuple.schema };
      if (!projectedDesired.has(schemaId) && !source.has(schemaId)) continue;
    }
    const id: StableId = {
      kind: "defaultPrivilege",
      role: tuple.creatingRole,
      schema: tuple.schema,
      objtype: tuple.objtype,
      grantee: tuple.grantee,
    };
    if (projectedDesired.has(id) || source.has(id)) continue;
    if (producerOf.has(encodeId(id))) continue;
    const fact: Fact = {
      id,
      payload: { privileges: [], grantable: [] },
      ...(tuple.schema != null
        ? { parent: { kind: "schema" as const, name: tuple.schema } }
        : {}),
    };
    emitCreate(fact, projectedDesired);
  }

  // creates — parents first, so a parent's delta-set inlining (e.g. a
  // partitioned table's columns rendered inside its CREATE, registered via
  // alsoProduces) is visible before its children are considered
  const depthOf = (fact: Fact): number => {
    let depth = 0;
    let parent = fact.parent;
    while (parent !== undefined) {
      depth++;
      parent = desired.get(parent)?.parent;
    }
    return depth;
  };
  for (const fact of [...added.values()].sort(
    (a, b) => depthOf(a) - depthOf(b),
  )) {
    if (producerOf.has(encodeId(fact.id))) continue;
    // EMISSION sees the PROJECTED plan target, not full `desired`: a child fact
    // whose own add delta was policy-filtered (a column's DEFAULT, a partitioned
    // table's column, a composite type's attribute, a publication's relation) is
    // absent here, so create rules cannot inline it via `alsoProduces` (review
    // P1 #1). buildActionGraph still reads un-projected `desired` for the
    // missing-requirement invariant — the two views are deliberately distinct
    // (docs/roadmap/tier-3-engine-refactors.md §1).
    emitCreate(fact, projectedDesired);
  }

  // create-produces-its-fact invariant (review architecture rec #2): every
  // worklist `add` must be materialized by a producing action — either its own
  // create or a parent's `alsoProduces` inlining. A create rule that returns no
  // producing action would otherwise surface only later as a missing-requirement
  // (or, like the role-config bug, silently lose payload). This is the
  // STRUCTURAL floor of "a create materializes the desired fact"; full per-kind
  // payload materialization (e.g. role GUC config) is each create rule's own
  // contract, pinned by its rule test.
  for (const fact of added.values()) {
    if (!producerOf.has(encodeId(fact.id))) {
      throw new Error(
        `emit invariant: added fact ${encodeId(fact.id)} (kind '${fact.id.kind}') ` +
          `is not materialized by any create action — its create rule must produce it`,
      );
    }
  }

  // default-privilege hygiene: objects created under active default ACLs receive
  // implicit grants; revoke them when the desired state has no corresponding acl
  // fact (pg_dump-style clean slate). EMISSION reads the PROJECTED plan target,
  // not full `desired`: a policy can filter the default-privilege add AND its
  // grantee role. Overlay hygiene is separately gated (`overlayHygieneGrantees`)
  // so assumed overlay roles skip the requirement guard without failing apply
  // on dests that never had them. Mirrors the create/alter seam.
  //
  // Hygiene covers every fact this plan CREATES on the target: added facts AND
  // replaced facts (drop + recreate) with their replace-recreated descendants —
  // a recreate fires active default ACLs exactly like a fresh create. The ADP
  // itself may be UNCHANGED (present on both sides, no delta) yet still inject
  // a grant the desired object never had, because on the source the object
  // predated the ADP (regression: the Supabase baseline's replaced
  // extensions.grant_pg_net_access() acquired a stale `postgres` grant from the
  // image's pre-existing default privileges).
  const hygieneTargets: Fact[] = [...added.values()];
  for (const key of [
    ...replaceIds,
    ...recreatedByReplace,
    ...inlinedByReplace,
  ]) {
    const fact = projectedDesired.getByEncoded(key);
    if (fact) hygieneTargets.push(fact);
  }
  // owner is now an edge, not a payload field (move 2). Database-scope
  // export/apply prunes the edge to the implicit default owner; hygiene falls
  // back to that name so it still fires.
  const ownerOf = (id: StableId): string | undefined => {
    const ownerEdge = projectedDesired
      .outgoingEdges(id)
      .find((e) => e.kind === "owner");
    return ownerEdge?.to.kind === "role"
      ? (ownerEdge.to as { kind: "role"; name: string }).name
      : undefined;
  };
  // `target` receives the default grants; `after` is the created fact whose
  // CREATE materializes it (the object itself, or the column for the backing
  // sequence of an identity column).
  const hygieneFor = (
    target: StableId,
    objtype: string,
    schema: string | null,
    creatingRole: string | undefined,
    after: StableId,
  ): void => {
    const revoked = new Set<string>();
    const emitHygieneRevoke = (grantee: string): void => {
      if (typeof creatingRole === "string" && grantee === creatingRole) return;
      if (revoked.has(grantee)) return;
      const aclId: StableId = { kind: "acl", target, grantee };
      if (projectedDesired.has(aclId)) return;
      revoked.add(grantee);
      pushAction(
        "alter",
        {
          sql: renderRevokeAllSql(target, [grantee]),
          consumes:
            grantee === "PUBLIC"
              ? []
              : [{ kind: "role", name: grantee } as StableId],
        },
        {
          consumes: [after],
          // the wipe also revokes this grantee's desired column grants
          wipes: columnAclIdsFor(aclId, projectedDesired),
        },
      );
    };
    if (typeof creatingRole === "string") {
      for (const dp of projectedDesired.facts()) {
        if (dp.id.kind !== "defaultPrivilege") continue;
        const dpid = dp.id as {
          role: string;
          schema: string | null;
          objtype: string;
          grantee: string;
        };
        if (dpid.role !== creatingRole || dpid.objtype !== objtype) continue;
        if (dpid.schema != null && dpid.schema !== schema) continue;
        emitHygieneRevoke(dpid.grantee);
      }
    }
    // Object CREATE is applier-scoped: the tuple's creatingRole names who would
    // inject ADP, not the object's owner. Match objtype + schema + grantee.
    for (const tuple of assumedDefaultGrants) {
      if (tuple.objtype !== objtype) continue;
      if (tuple.schema != null && tuple.schema !== schema) continue;
      if (!overlayHygieneGrantees.has(tuple.grantee)) continue;
      emitHygieneRevoke(tuple.grantee);
    }
  };
  for (const fact of hygieneTargets) {
    // a created object whose fact is absent from the projected target (its add
    // was effectively reverted) has no hygiene to do
    if (!projectedDesired.has(fact.id)) continue;
    // which pg_default_acl objtype this kind maps to is declared per-kind in the
    // rule table (`defaclObjtype`); absent → no default ACLs of its own
    const objtype = ruleFlag(fact.id.kind, "defaclObjtype");
    if (objtype !== undefined) {
      hygieneFor(
        fact.id,
        objtype,
        (fact.id as { schema?: string }).schema ?? null,
        ownerOf(fact.id) ?? defaultOwner,
        fact.id,
      );
    }
    // An identity column materializes its backing sequence, which receives
    // SEQUENCES default grants the same way; the sequence is not a fact, so its
    // hygiene hangs off the column and its owner is the table's.
    if (fact.id.kind === "column" && fact.parent !== undefined) {
      const sequence = identitySequenceId(fact.payload["identity"]);
      if (sequence !== null && sequence.kind === "sequence") {
        hygieneFor(
          sequence,
          "S",
          sequence.schema,
          ownerOf(fact.parent) ?? defaultOwner,
          fact.id,
        );
      }
    }
  }

  // ADD IDENTITY on an existing column materializes a backing sequence in
  // place: it takes SEQUENCES default grants like a fresh create, but the column
  // is neither added nor replaced, so the loop above never sees it. The REVOKE
  // consumes the sequence the ADD IDENTITY alter produces. A column a replace
  // re-creates has no such alter (its create materializes the sequence) and
  // already took hygiene above.
  for (const [key, sets] of setsByFact) {
    if (!sets.some((s) => s.attr === "identity")) continue;
    if (
      replaceIds.has(key) ||
      recreatedByReplace.has(key) ||
      inlinedByReplace.has(key)
    )
      continue;
    if (source.getByEncoded(key)?.payload["identity"] != null) continue;
    const fact = projectedDesired.getByEncoded(key);
    if (fact === undefined || fact.id.kind !== "column") continue;
    if (fact.parent === undefined) continue;
    const sequence = identitySequenceId(fact.payload["identity"]);
    if (sequence === null || sequence.kind !== "sequence") continue;
    hygieneFor(
      sequence,
      "S",
      sequence.schema,
      ownerOf(fact.parent) ?? defaultOwner,
      sequence,
    );
    // A grant on a standalone sequence of the same name (serial → identity)
    // keeps its acl id: the diff sees it unchanged under the column while the
    // DROP SEQUENCE destroys it. Replay it onto the new backing sequence.
    const sequenceKey = encodeId(sequence);
    for (const child of projectedDesired.childrenOf(fact.id)) {
      if (child.id.kind !== "acl") continue;
      if (encodeId(child.id.target) !== sequenceKey) continue;
      const childKey = encodeId(child.id);
      if (added.has(childKey) || producerOf.has(childKey)) continue;
      emitCreate(child, projectedDesired);
    }
  }

  // drops (suppressed children fold into their root's destroys)
  const destroysByRoot = new Map<string, StableId[]>();
  for (const [key, fact] of removed) {
    const root = dropRootOf.get(key) as string;
    const list = destroysByRoot.get(root) ?? [];
    list.push(fact.id);
    destroysByRoot.set(root, list);
  }
  for (const [key, fact] of removed) {
    if (dropRootOf.get(key) !== key) continue; // suppressed
    if (replaceIds.has(key)) continue; // replace handles its own drop
    // pass the resolved SOURCE view so a drop rule can read the fact's context
    // (e.g. DROP EXTENSION derives data-loss from its members' edges).
    const spec = rulesForId(fact.id).drop(fact, source);
    const seen = new Set<string>([key]);
    const destroyList: StableId[] = [fact.id];
    // `destroysByRoot` is removed-only. A replaced attached child is not in
    // `removed`; DROP INDEX on the old parent still cascades it, so CREATE
    // must wait on this drop.
    for (const id of [
      ...(destroysByRoot.get(key) ?? []),
      ...redirectedOnto(key),
    ]) {
      const idKey = encodeId(id);
      if (seen.has(idKey)) continue;
      seen.add(idKey);
      destroyList.push(id);
    }
    pushAction("drop", spec, {
      consumes: fact.parent !== undefined ? [fact.parent] : [],
      // the root fact leads: it is the action's subject (tie-break, locks)
      destroys: destroyList,
      wipes: implicitlyDestroyed(fact),
    });
  }

  // in-place alters (skipped for facts a replace already recreated)
  for (const [key, sets] of setsByFact) {
    if (
      replaceIds.has(key) ||
      recreatedByReplace.has(key) ||
      inlinedByReplace.has(key)
    ) {
      continue;
    }
    // alters also render against the PROJECTED plan target: an alter that inlines
    // a child reference (ALTER COLUMN … TYPE … re-applying the desired DEFAULT,
    // REPLICA IDENTITY USING a desired index) must not surface a filtered-out
    // child (review P1 #1). `source` stays as the from-state for the rule.
    const fact = projectedDesired.get(sets[0]!.id) as Fact;
    const rules = rulesForId(fact.id);
    for (const s of sets) {
      const attrRule = rules.attributes[s.attr];
      if (attrRule === undefined || attrRule === "replace") continue;
      const specs = attrRule.alter(
        fact,
        s.from,
        s.to,
        projectedDesired,
        source,
      );
      for (const spec of Array.isArray(specs) ? specs : [specs]) {
        pushAction("alter", spec, { consumes: [fact.id] });
      }
    }
  }

  // owner-edge changes: emit ALTER … OWNER TO from link/unlink deltas (move 2:
  // owner is now an edge, not a payload attribute)
  {
    // collect old owner roles per fact so the link action can release them
    const oldOwnerByFact = new Map<string, StableId>();
    for (const delta of deltas) {
      if (delta.verb !== "unlink" || delta.edge.kind !== "owner") continue;
      oldOwnerByFact.set(encodeId(delta.edge.from), delta.edge.to);
    }
    // Accepted object renames preserve ownership. Map each renamed-to id to the
    // owner its rename-from counterpart held in canonical source. Any accepted
    // role rename is already reflected in that source edge, so a dual object +
    // owner-role rename compares as unchanged without carry bookkeeping.
    const renamedOwner = new Map<string, string | null>();
    // and the OLD owner's StableId, so a genuinely-changed owner's link action
    // can `releases` it (the source-side unlink is keyed by the OLD id, which
    // the destination link never looks up — review P1 #1: drop old role too
    // early).
    const renamedOwnerId = new Map<string, StableId>();
    for (const { from, to } of acceptedRenames) {
      const srcIds = subtreeIds(source, from.id);
      const dstIds = subtreeIds(desired, to.id);
      for (let i = 0; i < dstIds.length; i++) {
        const srcId = srcIds[i];
        const dstId = dstIds[i];
        if (srcId === undefined || dstId === undefined) continue;
        const ownerEdge = source
          .outgoingEdges(srcId)
          .find((e) => e.kind === "owner");
        if (ownerEdge?.to.kind !== "role") {
          renamedOwner.set(encodeId(dstId), null);
          continue;
        }
        const srcOwnerName = (ownerEdge.to as { name: string }).name;
        renamedOwner.set(encodeId(dstId), srcOwnerName);
        renamedOwnerId.set(encodeId(dstId), ownerEdge.to);
      }
    }
    // objKeys whose owner a link delta already (re-)established below, so the
    // replaced-fact pass does not emit a second ALTER … OWNER TO for them.
    const ownerEmitted = new Set<string>();
    for (const delta of deltas) {
      if (delta.verb !== "link" || delta.edge.kind !== "owner") continue;
      const objId = delta.edge.from;
      const objKey = encodeId(objId);
      // Created objects need this too: create no longer sets the owner (move 2),
      // so a fresh object owned by a non-applier role needs an explicit
      // ALTER … OWNER TO, ordered after its create (consumes: [objId]) and after
      // the role. An owner role projected out of the view has no edge here (it
      // was pruned), so the object is left applier-owned — skipAuthorization
      // elimination falls out for free.
      const fact = desired.get(objId);
      if (!fact) continue;
      const ownerAlterPrefix = ruleFlag(fact.id.kind, "ownerAlterPrefix");
      if (!ownerAlterPrefix) continue;
      const prefix = ownerAlterPrefix(fact);
      const newRoleId = delta.edge.to;
      if (newRoleId.kind !== "role") continue;
      const roleName = (newRoleId as { kind: "role"; name: string }).name;
      // ownership carried unchanged by an accepted OBJECT rename (the object id
      // changed; renamedOwner maps it through any role rename) — no action
      if (renamedOwner.get(objKey) === roleName) continue;
      // Owner residue (move 6): `ALTER … OWNER TO R` requires the applier to be
      // a superuser or a member of R. If a capability is supplied and the
      // applier cannot, fail fast at plan time with an actionable message —
      // surfaced before any statement runs, and avoiding a non-converging
      // "leave it applier-owned" (the owner is acldefault-relative). Unset only
      // for owner CHANGES/creates (this is an owner link delta), not pre-existing
      // unchanged ownership.
      if (capability !== undefined && !canSetOwner(capability, roleName)) {
        throw new Error(
          `capability: cannot set owner of ${encodeId(objId)} to role "${roleName}" — applier "${capability.role}" is not a superuser or a member of that role; grant membership or apply as a member/superuser`,
        );
      }
      // for an accepted rename the source-side owner unlink is keyed by the OLD
      // id, so `oldOwnerByFact` (keyed by the link's `from`, i.e. the NEW id) has
      // no entry — fall back to the owner the renamed subtree carried in source
      // (review P1 #1), so the release edge orders this before the old role drop.
      const oldRoleId =
        oldOwnerByFact.get(objKey) ?? renamedOwnerId.get(objKey);
      pushAction(
        "alter",
        {
          sql: `${prefix} OWNER TO ${qid(roleName)}`,
          consumes: [newRoleId],
          ...(oldRoleId !== undefined ? { releases: [oldRoleId] } : {}),
        },
        { consumes: [objId] },
      );
      ownerEmitted.add(objKey);
    }

    // Replaced facts (drop + recreate) revert to the applying role's ownership;
    // their owner edge is UNCHANGED source->target so it produced no owner link
    // delta above. Re-establish it from the PROJECTED target for every replaced
    // fact (and any descendant a replace recreated) a link delta did not already
    // own — mirroring how the replace loop recreates child ACL facts. Without
    // this, a function/type/table whose body/definition changed is silently
    // re-owned to whoever runs the migration (regression: Supabase auth.uid() et
    // al., owned by supabase_auth_admin, reverted to the applier after replace).
    for (const key of [...replaceIds, ...recreatedByReplace]) {
      if (ownerEmitted.has(key)) continue;
      const fact = projectedDesired.getByEncoded(key);
      if (!fact) continue;
      const ownerAlterPrefix = ruleFlag(fact.id.kind, "ownerAlterPrefix");
      if (!ownerAlterPrefix) continue;
      const ownerEdge = projectedDesired
        .outgoingEdges(fact.id)
        .find((e) => e.kind === "owner");
      if (ownerEdge?.to.kind !== "role") continue;
      const roleName = (ownerEdge.to as { kind: "role"; name: string }).name;
      if (capability !== undefined && !canSetOwner(capability, roleName)) {
        throw new Error(
          `capability: cannot set owner of ${key} to role "${roleName}" — ` +
            `applier "${capability.role}" is not a superuser or a member of that role; ` +
            `grant membership or apply as a member/superuser`,
        );
      }
      pushAction(
        "alter",
        {
          sql: `${ownerAlterPrefix(fact)} OWNER TO ${qid(roleName)}`,
          consumes: [ownerEdge.to],
        },
        { consumes: [fact.id] },
      );
    }
  }

  return {
    actions,
    producerOf,
    destroyerOf,
    foldHints,
    acceptsFolds,
    renameActionIndices,
    implicitDestroys,
  };
}
