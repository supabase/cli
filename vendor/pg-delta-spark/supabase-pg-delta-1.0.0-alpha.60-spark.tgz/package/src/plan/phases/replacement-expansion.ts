/**
 * Planner phase 2 — ReplacementExpansion (target-architecture §3.4–3.5).
 *
 * Given the grouped change set, decides which facts are REPLACED (drop +
 * recreate) versus altered in place, expands the forced dependent rebuild, and
 * computes drop-root suppression/redirect. Pure over its inputs; produces the
 * `replaceIds` set and the `dropRootOf` map the emitter consumes. Extracted from
 * `plan()` so the replace/rebuild/suppression invariants live behind one named
 * boundary instead of inline.
 */
import type { Delta } from "../../core/diff.ts";
import type { Fact, FactBase } from "../../core/fact.ts";
import { encodeId, encodeIdMemo, type StableId } from "../../core/stable-id.ts";
import { stronglyConnectedComponents } from "../graph.ts";
import { cascadesToChildren, isRebuildable } from "../rule-flags.ts";
import type { ReplaceRootChange, RulesForId } from "../rules.ts";

export interface ReplacementExpansionInput {
  /** removed / added facts keyed by encoded id (ordinary rename cancellation
   *  applied) */
  removed: ReadonlyMap<string, Fact>;
  added: ReadonlyMap<string, Fact>;
  /** set-deltas grouped by encoded fact id */
  setsByFact: ReadonlyMap<string, Extract<Delta, { verb: "set" }>[]>;
  /** resolved source / desired views */
  source: FactBase;
  desired: FactBase;
  /** desired with policy-excluded deltas kept in their source form — the
   *  state the plan converges to and the emitter recreates from */
  projectedDesired: FactBase;
  /** id-keyed rule resolver (schema kinds + `extensionIntent`) */
  rulesForId: RulesForId;
}

export interface ReplacementExpansion {
  /** encoded ids the planner replaces (drop old + recreate from desired) */
  replaceIds: Set<string>;
  /** encoded id → encoded id of the drop action that subsumes it (suppression) */
  dropRootOf: Map<string, string>;
}

/**
 * Classify set-deltas (in-place alter vs replace), expand the forced dependent
 * rebuild, then compute drop-root suppression + redirect. Behavior-preserving
 * extraction of `plan()`'s replacement/suppression block.
 */
export function expandReplacements(
  input: ReplacementExpansionInput,
): ReplacementExpansion {
  const {
    removed,
    added,
    setsByFact,
    source,
    desired,
    projectedDesired,
    rulesForId,
  } = input;

  // ── classify set-deltas: in-place alter vs replace ────────────────────
  const replaceIds = new Set<string>();
  // alters that invalidate dependents (e.g. an enum value-set replacement, or an
  // ALTER COLUMN TYPE that views/policies reference) seed the forced-rebuild
  // pass without replacing the fact itself. The value is the set of dependent
  // kinds to rebuild (null = all rebuildable kinds).
  const rebuildSeeds = new Map<string, ReadonlySet<string> | null>();
  for (const [key, sets] of setsByFact) {
    const fact = desired.get(sets[0]!.id) as Fact;
    const rules = rulesForId(fact.id);
    for (const s of sets) {
      const attrRule = rules.attributes[s.attr];
      if (attrRule === undefined) {
        throw new Error(
          `rule table: kind '${fact.id.kind}' has no rule for attribute '${s.attr}' (${key}) — extend the rule vocabulary (guardrail 3)`,
        );
      }
      if (attrRule === "replace") {
        replaceIds.add(key);
        continue;
      }
      // a transition with no in-place ALTER grammar routes the whole fact to
      // replace (drop + recreate) — its `alter` is never rendered. Evaluated
      // against BOTH endpoint facts: the alter executes on the SOURCE database,
      // so source-side state governs its legality (a non-relocatable installed
      // extension version rejects SET SCHEMA even when the desired version is
      // relocatable), while the desired-side read stays as the conservative
      // end-state check. Replace always converges, so OR-ing can only widen
      // the replace set — never emit an illegal alter.
      const sourceFact = source.get(s.id);
      if (
        attrRule.replaceWhen?.(s.from, s.to, fact) ||
        (sourceFact !== undefined &&
          attrRule.replaceWhen?.(s.from, s.to, sourceFact))
      ) {
        replaceIds.add(key);
        continue;
      }
      const rebuild = attrRule.rebuildsDependents?.(s.from, s.to);
      if (rebuild === true) rebuildSeeds.set(key, null);
      else if (Array.isArray(rebuild)) rebuildSeeds.set(key, new Set(rebuild));
    }
  }

  // Some changes can't be applied to a fact on its own (a partition key
  // column can't be retyped or dropped). Its rule names an ancestor to replace
  // instead (`replaceRoot`), asked once per changed or removed fact. Check both
  // sides, as `replaceWhen` does: the change runs on the source, and the
  // create renders the desired state. A lifted set-delta fact also joins
  // `replaceIds` so the rebuild walk fully destroys its dependents; the
  // ancestor trim below then removes it, and the ancestor's subtree recreates
  // it. A removed fact folds into the ancestor's drop. An ancestor the plan
  // drops outright needs no lift: its DROP already takes the fact.
  {
    const lift = (
      key: string,
      change: ReplaceRootChange,
      facts: readonly (Fact | undefined)[],
    ): void => {
      for (const fact of facts) {
        if (fact === undefined) continue;
        const root = rulesForId(fact.id).replaceRoot?.(fact, change);
        if (root === undefined) continue;
        if (!source.has(root) || !desired.has(root)) continue;
        if (change.verb === "set") replaceIds.add(key);
        replaceIds.add(encodeId(root));
        return;
      }
    };
    for (const [key, sets] of setsByFact) {
      const attrs = new Set(sets.map((s) => s.attr));
      lift(key, { verb: "set", attrs }, [
        source.getByEncoded(key),
        desired.getByEncoded(key),
      ]);
    }
    for (const [key, fact] of removed) {
      lift(key, { verb: "remove" }, [fact]);
    }
  }

  const isRemovedId = (id: StableId): boolean => {
    const key = encodeId(id);
    return removed.has(key) || replaceIds.has(key);
  };

  // Surviving facts whose DROP folds into a destroyed ancestor
  // (`dropRootRedirect`) must rebuild: that DROP still cascades them even
  // when their payload is unchanged. Walk to a fixed point so a leaf
  // attached through a middle parent is included regardless of fact order.
  {
    let grew = true;
    while (grew) {
      grew = false;
      for (const fact of source.facts()) {
        if (!desired.has(fact.id)) continue;
        const key = encodeId(fact.id);
        if (replaceIds.has(key) || removed.has(key)) continue;
        if (
          rulesForId(fact.id).dropRootRedirect?.(fact, isRemovedId) ===
          undefined
        ) {
          continue;
        }
        replaceIds.add(key);
        grew = true;
      }
    }
  }

  // ── forced dependent rebuild (the clean expand-replace, §3.4) ─────────
  // A surviving dependent of something this plan destroys must be dropped and
  // recreated from the desired state — recursively. Which kinds are rebuildable
  // is declared per-kind in the rule table (`rebuildable`).
  {
    // `fullDestroy` ids rebuild EVERY rebuildable dependent; `rebuildSeeds` (an
    // in-place alter that invalidates only some dependent kinds) rebuild only
    // their declared kinds. Once a dependent is rebuilt it joins `fullDestroy`,
    // so its own subtree rebuilds completely.
    const fullDestroy = new Set([...removed.keys(), ...replaceIds]);
    const targets = new Set([...fullDestroy, ...rebuildSeeds.keys()]);
    // Reverse-dependency reachability from the initial targets, instead of
    // rescanning every source edge each fixpoint round (O(reachable) vs
    // O(edges × rounds)). Same checks/precedence as the fixpoint: a dependent of
    // a destroyed/replaced fact (or a kind-restricted seed) that is rebuildable
    // and survives in `desired` is replaced, and itself becomes a full-destroy
    // target so its own subtree rebuilds.
    const worklist = [...targets];
    while (worklist.length > 0) {
      const toKey = worklist.pop() as string;
      // Scan childrenOf as well as incoming `depends`. Views/policies often
      // depend on columns, not the table; partitions hang off the schema and
      // are found via inherit `depends` on the parent table itself. Children
      // stay scan-only here — ancestor trim + subtree recreate own them.
      const toFact = source.getByEncoded(toKey);
      if (toFact !== undefined && fullDestroy.has(toKey)) {
        for (const child of source.childrenOf(toFact.id)) {
          const childKey = encodeId(child.id);
          if (targets.has(childKey)) continue;
          targets.add(childKey);
          worklist.push(childKey);
        }
      }
      for (const edge of source.incomingEdgesByEncoded(toKey)) {
        const fromKey = encodeId(edge.from);
        if (targets.has(fromKey)) continue;
        const dependent = source.get(edge.from);
        if (!dependent || !desired.has(edge.from)) continue;
        // An extension MEMBER whose owning extension this plan DESTROYS (drop
        // or replace) is never a standalone action: it vanishes with the
        // extension's DROP (`alsoDestroys`) and re-materializes with the
        // CREATE. Promoting it into `replaceIds` emits member DROP/CREATE
        // statements PostgreSQL rejects outright — and, across an extension
        // replace, wedges the action graph (the pg_net member cycle,
        // guardrail 4). The walk still traverses THROUGH the member: its
        // non-member dependents are real casualties of the replace and must
        // rebuild (an unchanged user function calling a member function).
        // Scoped to members of a destroyed extension — a reference-only fact
        // kept by a POLICY (an assumed-schema platform object) does not
        // vanish, so it keeps the pre-existing rebuild path below.
        const vanishesWithExtension = source
          .outgoingEdges(dependent.id)
          .some(
            (e) =>
              e.kind === "memberOfExtension" && fullDestroy.has(encodeId(e.to)),
          );
        if (vanishesWithExtension) {
          fullDestroy.add(fromKey);
          targets.add(fromKey);
          worklist.push(fromKey);
          continue;
        }
        if (!isRebuildable(dependent.id.kind)) continue;
        // reached only via a kind-restricted seed: honor the allowed kinds
        if (!fullDestroy.has(toKey)) {
          const allowed = rebuildSeeds.get(toKey);
          if (allowed && !allowed.has(dependent.id.kind)) continue;
        }
        replaceIds.add(fromKey);
        fullDestroy.add(fromKey);
        targets.add(fromKey);
        worklist.push(fromKey);
      }
    }
    // ── survivors wiped as a side effect of a create / drop of this plan ───
    // (`implicitlyDestroys`, e.g. an object-level REVOKE ALL and the grantee's
    // column acls): a wiped fact that survives unchanged into the projected
    // target (including one a policy kept) must be recreated; one with its own
    // add / replace already recreates itself.
    for (const key of [...added.keys(), ...removed.keys(), ...replaceIds]) {
      const fact =
        projectedDesired.getByEncoded(key) ?? source.getByEncoded(key);
      if (fact === undefined) continue;
      const wiped = rulesForId(fact.id).implicitlyDestroys?.(
        fact,
        projectedDesired,
        source,
      );
      for (const id of wiped ?? []) {
        const wipedKey = encodeId(id);
        if (added.has(wipedKey) || replaceIds.has(wipedKey)) continue;
        if (!source.has(id) || !projectedDesired.has(id)) continue;
        replaceIds.add(wipedKey);
      }
    }
    // descendants of replaced facts are handled by the ancestor's subtree
    // recreate — keep only the topmost replaced facts. Deleting the entry under
    // iteration is safe for a JS Set.
    for (const key of replaceIds) {
      const fact = source.getByEncoded(key);
      let ancestor = fact?.parent;
      while (ancestor !== undefined) {
        if (replaceIds.has(encodeId(ancestor))) {
          replaceIds.delete(key);
          break;
        }
        ancestor = source.get(ancestor)?.parent;
      }
    }
  }

  // ── suppression: child removals that cascade with an ancestor's drop ──
  // dropRootOf(id) = nearest removed ancestor whose drop action will exist. FK
  // constraint drops are NEVER suppressed: an explicit DROP CONSTRAINT before
  // the table drops makes mutual-FK teardown cycles unconstructible
  // (decomposition over repair, §3.5). `unfolded` children keep their own drop
  // for the same reason (see the bridge pass below).
  const redirectFacts: Fact[] = [...removed.values()];
  for (const key of replaceIds) {
    const fact = source.getByEncoded(key);
    if (fact !== undefined) redirectFacts.push(fact);
  }
  const computeDropRoots = (
    unfolded: ReadonlySet<string>,
  ): Map<string, string> => {
    const dropRootOf = new Map<string, string>();
    const findDropRoot = (fact: Fact): string => {
      const key = encodeId(fact.id);
      const cached = dropRootOf.get(key);
      if (cached) return cached;
      let root = key;
      const rules = rulesForId(fact.id);
      const suppressible = rules.suppressible?.(fact) ?? true;
      const parent = fact.parent;
      if (parent !== undefined && suppressible && !unfolded.has(key)) {
        const parentRemoved = isRemovedId(parent);
        // a metadata satellite folds into ANY removed parent; otherwise the parent
        // kind must be one whose DROP cascades to children
        const cascades =
          rules.metadata === true || cascadesToChildren(parent.kind);
        if (parentRemoved && cascades) {
          root = findDropRoot(
            removed.get(encodeId(parent)) ?? (source.get(parent) as Fact),
          );
        }
      }
      dropRootOf.set(key, root);
      return root;
    };
    for (const fact of removed.values()) findDropRoot(fact);

    // a fact whose drop folds into a NON-parent ancestor (an OWNED BY sequence
    // into its owning column/table, an attached child index into its parent
    // index) — declared per-kind via dropRootRedirect. Replaced facts are not
    // in `removed`; without this pass their DROP is emitted next to the parent
    // replace and PostgreSQL rejects `DROP INDEX` on an attached child. A
    // redirect wins over `unfolded`: the only bridgeable redirected kind, an
    // attached partition index, follows its parent index, which bridges and
    // unfolds in the same round.
    for (const fact of redirectFacts) {
      const redirect = rulesForId(fact.id).dropRootRedirect?.(
        fact,
        isRemovedId,
      );
      if (redirect === undefined) continue;
      const redirectKey = encodeId(redirect);
      dropRootOf.set(
        encodeId(fact.id),
        dropRootOf.get(redirectKey) ?? redirectKey,
      );
    }
    return dropRootOf;
  };

  // A folded child that depends on a separately dropped object which itself
  // reaches back into the child's drop root cannot ride that root's DROP: an
  // index or CHECK calling f(t), where f takes t's row type, puts DROP t before
  // DROP f (the child dies with t) while f must go first (it depends on t's
  // row type). Unfold such children so their own DROP precedes f.
  const findBridgedChildren = (
    roots: ReadonlyMap<string, string>,
    unfolded: ReadonlySet<string>,
  ): string[] => {
    // a replaced fact (e.g. a function rebuilt because it takes a replaced
    // table's row type) is dropped by its own replace action: a root too
    const rootOf = (key: string): string | undefined =>
      roots.get(key) ?? (replaceIds.has(key) ? key : undefined);
    // folded children with a dependency dropped under another root, by root
    const candidatesByRoot = new Map<string, string[]>();
    for (const [key, root] of roots) {
      if (root === key || unfolded.has(key)) continue;
      for (const edge of source.outgoingEdgesByEncoded(key)) {
        const toRoot = rootOf(encodeIdMemo(edge.to));
        if (toRoot === undefined || toRoot === root) continue;
        const list = candidatesByRoot.get(root) ?? [];
        list.push(key);
        candidatesByRoot.set(root, list);
        break;
      }
    }
    if (candidatesByRoot.size === 0) return [];
    // Drop-root graph: A -> B when a member of A depends on a member of B. A
    // folded child bridges when its dependency's root shares its own root's
    // strongly connected component: folding it would close that loop. Roots,
    // not single facts: a domain whose folded CHECK reaches the table drops as
    // one action, while a column depends on the domain itself.
    const dependsOn = new Map<string, Set<string>>();
    const addEdges = (key: string, root: string): void => {
      for (const edge of source.outgoingEdgesByEncoded(key)) {
        const toRoot = rootOf(encodeIdMemo(edge.to));
        if (toRoot === undefined || toRoot === root) continue;
        const targets = dependsOn.get(root) ?? new Set<string>();
        targets.add(toRoot);
        dependsOn.set(root, targets);
      }
    };
    for (const [key, root] of roots) addEdges(key, root);
    for (const key of replaceIds) if (!roots.has(key)) addEdges(key, key);
    const sccOf = stronglyConnectedComponents(dependsOn);
    const bridged: string[] = [];
    for (const [root, candidates] of candidatesByRoot) {
      for (const key of candidates) {
        const bridges = source.outgoingEdgesByEncoded(key).some((edge) => {
          const toRoot = rootOf(encodeIdMemo(edge.to));
          return (
            toRoot !== undefined &&
            toRoot !== root &&
            sccOf.get(toRoot) === sccOf.get(root)
          );
        });
        if (bridges) bridged.push(key);
      }
    }
    return bridged;
  };

  // Unfolding re-roots the child's own satellites, which can expose another
  // bridge, so repeat until none is left. Each round only adds keys not yet in
  // `unfolded`, so this ends within |removed| rounds (one in practice).
  const unfolded = new Set<string>();
  let dropRootOf = computeDropRoots(unfolded);
  let bridged = findBridgedChildren(dropRootOf, unfolded);
  while (bridged.length > 0) {
    for (const key of bridged) unfolded.add(key);
    dropRootOf = computeDropRoots(unfolded);
    bridged = findBridgedChildren(dropRootOf, unfolded);
  }

  return { replaceIds, dropRootOf };
}
