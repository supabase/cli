/**
 * Unit tests for the integration profile (src/integrations/profile.ts).
 * No Docker: the only DB touch is `probeApplierCapability` / pgMajor, mocked.
 *
 * The profile is the single object that owns "what state may the engine manage?"
 * — it resolves policy + capability + baseline ONCE against a source pool and
 * bakes them into plan/prove/apply option bundles, so all three reconstruct the
 * SAME managed view (plan == prove == apply) by construction.
 */
import { describe, expect, test } from "bun:test";
import type { Pool } from "pg";
import { buildFactBase } from "../core/fact.ts";
import { supabasePolicy } from "../policy/supabase.ts";
import type { IntegrationProfile } from "./profile.ts";
import { rawProfile, resolveProfile } from "./profile.ts";
import { supabaseProfile } from "./supabase.ts";

/** A mock pool: capability probe + server_version_num are the only queries. */
function mockPool(opts: {
  superuser?: boolean;
  memberOf?: string[];
  versionNum?: number;
}): Pool {
  return {
    // biome-ignore lint: minimal pg.Pool stand-in for unit tests
    query: async (sql: string) => {
      if (sql.includes("current_user")) {
        return {
          rows: [
            {
              role: "applier",
              is_superuser: opts.superuser ?? false,
              create_role: false,
              pg_major: Math.floor((opts.versionNum ?? 170004) / 10000),
              member_of: opts.memberOf ?? [],
            },
          ],
        };
      }
      if (sql.includes("server_version_num")) {
        return { rows: [{ v: opts.versionNum ?? 170004 }] };
      }
      return {
        rows: [
          {
            role: "applier",
            is_superuser: opts.superuser ?? false,
            member_of: opts.memberOf ?? [],
          },
        ],
      };
    },
  } as unknown as Pool;
}

describe("resolveProfile", () => {
  test("rawProfile composes a policy-free view; capability is probed by default", async () => {
    const ctx = await resolveProfile(mockPool({}), rawProfile);
    expect(ctx.id).toBe("raw");
    expect(ctx.planOptions.policy).toBeUndefined();
    expect(ctx.planOptions.capability).toBeDefined();
    expect(ctx.planOptions.capability?.isSuperuser).toBe(false);
    expect(ctx.planOptions.baseline).toBeUndefined();
    expect(ctx.handlers.map((h) => h.extension)).toEqual(["supabase_vault"]);
    expect(typeof ctx.proveOptions.reextract).toBe("function");
    expect(typeof ctx.applyOptions.reextract).toBe("function");
  });

  test("supabaseProfile carries the Supabase policy into all three bundles", async () => {
    const ctx = await resolveProfile(mockPool({}), supabaseProfile);
    expect(ctx.id).toBe("supabase");
    expect(ctx.handlers.map((h) => h.extension)).not.toContain(
      "supabase_vault",
    );
    expect(ctx.planOptions.policy).toBe(supabasePolicy);
    expect(ctx.proveOptions.policy).toBe(supabasePolicy);
    // baseline is unset on the v1 Supabase policy → resolves cleanly to none
    expect(ctx.planOptions.baseline).toBeUndefined();
    expect(ctx.applyOptions.baseline).toBeUndefined();
  });

  test("planOptions carries the profile id so plan() can stamp the artifact", async () => {
    const supa = await resolveProfile(mockPool({}), supabaseProfile);
    expect(supa.planOptions.profile).toEqual({ id: "supabase" });
    const raw = await resolveProfile(mockPool({}), rawProfile);
    expect(raw.planOptions.profile).toEqual({ id: "raw" });
  });

  test("omitted restrictToApplier probes capability and threads it consistently", async () => {
    const ctx = await resolveProfile(
      mockPool({ superuser: false }),
      supabaseProfile,
    );
    expect(ctx.planOptions.capability).toBeDefined();
    expect(ctx.planOptions.capability?.isSuperuser).toBe(false);
    expect(ctx.proveOptions.capability).toBe(ctx.planOptions.capability);
  });

  test("restrictToApplier: true is the same explicit probe", async () => {
    const ctx = await resolveProfile(
      mockPool({ superuser: false }),
      supabaseProfile,
      { restrictToApplier: true },
    );
    expect(ctx.planOptions.capability).toBeDefined();
    expect(ctx.proveOptions.capability).toBe(ctx.planOptions.capability);
  });

  test("restrictToApplier: false leaves the managed view unrestricted", async () => {
    const ctx = await resolveProfile(mockPool({}), supabaseProfile, {
      restrictToApplier: false,
    });
    expect(ctx.planOptions.capability).toBeUndefined();
    expect(ctx.proveOptions.capability).toBeUndefined();
  });

  test("an explicit baseline override is threaded into all three bundles + stamped", async () => {
    // a caller (library / test) can supply a pre-loaded LoadedBaseline for a
    // profile with no policy-declared baseline. The engine option is its
    // FactBase; the digest is stamped on planOptions.baselineMeta + ctx.baseline.
    const factBase = buildFactBase(
      [{ id: { kind: "schema", name: "platform" }, payload: {} }],
      [],
    );
    const baseline = { factBase, digest: factBase.rootHash };
    const ctx = await resolveProfile(mockPool({}), rawProfile, { baseline });
    expect(ctx.planOptions.baseline).toBe(factBase);
    expect(ctx.proveOptions.baseline).toBe(factBase);
    expect(ctx.applyOptions.baseline).toBe(factBase);
    expect(ctx.planOptions.baselineMeta?.digest).toBe(factBase.rootHash);
    expect(ctx.baseline?.digest).toBe(factBase.rootHash);
  });

  test("an explicit baseline override wins over a policy-declared baseline name", async () => {
    // profile whose policy declares a baseline NAME (which would resolve from
    // the committed baselines dir); the explicit override replaces it without
    // touching the dir, so a missing committed snapshot never even matters.
    const factBase = buildFactBase(
      [{ id: { kind: "schema", name: "x" }, payload: {} }],
      [],
    );
    const override = { factBase, digest: factBase.rootHash };
    const profile: IntegrationProfile = {
      id: "p",
      handlers: [],
      policy: {
        id: "pol",
        baseline: "nonexistent-committed-baseline",
        filter: [],
      },
    };
    const ctx = await resolveProfile(mockPool({}), profile, {
      baseline: override,
    });
    expect(ctx.planOptions.baseline).toBe(factBase);
  });

  test("rejects a baseline whose redaction mode differs from the command's", async () => {
    // a baseline captured redacted, applied by a command extracting unredacted
    // (or vice versa) would silently stop subtracting — fail loud.
    const factBase = buildFactBase(
      [{ id: { kind: "schema", name: "platform" }, payload: {} }],
      [],
    );
    const baseline = {
      factBase,
      digest: factBase.rootHash,
      redactSecrets: true,
    };
    let err: unknown;
    try {
      await resolveProfile(mockPool({}), rawProfile, {
        baseline,
        redactSecrets: false,
      });
    } catch (e) {
      err = e;
    }
    expect(err).toBeInstanceOf(Error);
    expect((err as Error).message).toMatch(/redactSecrets/);
  });

  test("skipBaseline resolves handlers only — a missing declared baseline does not fail", async () => {
    // snapshot/drift capture handler-aware facts and never subtract a baseline;
    // a profile that DECLARES a baseline (e.g. the file this snapshot is about to
    // write) must not make resolution fail loading a not-yet-existent file.
    const profile: IntegrationProfile = {
      id: "p",
      handlers: [],
      baselinePath: "/no/such/baseline-snapshot.json",
    };
    const ctx = await resolveProfile(mockPool({}), profile, {
      skipBaseline: true,
    });
    expect(ctx.baseline).toBeUndefined();
    expect(ctx.planOptions.baseline).toBeUndefined();
  });
});
