/**
 * supabase/cli#5555: a declarative sync must not drop platform-managed
 * extensions (the reported `DROP EXTENSION pg_graphql`). The supabase policy
 * projects those extensions out of the managed view entirely — so an extension
 * present on the target but absent from the declarative source produces no
 * remove delta and thus no DROP — while leaving user-declarable extensions
 * (pg_trgm, …) fully managed. Before the fix, pg_graphql was kept in the view
 * and would be dropped. Pure policy level — no DB.
 */
import { describe, expect, test } from "bun:test";
import { buildFactBase, type Fact } from "../core/fact.ts";
import type { StableId } from "../core/stable-id.ts";
import { resolveView } from "./policy.ts";
import { supabasePolicy } from "./supabase.ts";

const ext = (name: string, schema: string): Fact => ({
  id: { kind: "extension", name },
  payload: { schema, _relocatable: false },
});
const pgGraphql: StableId = { kind: "extension", name: "pg_graphql" };
const pgTrgm: StableId = { kind: "extension", name: "pg_trgm" };
const wrappers: StableId = { kind: "extension", name: "wrappers" };
const orioledb: StableId = { kind: "extension", name: "orioledb" };

describe("supabase policy — platform extensions", () => {
  test("keeps orioledb reference-only and projects out its comment", () => {
    // The OrioleDB image's tables depend on `orioledb`, so it must survive for
    // the shadow seed, but neither it nor its platform comment is ever diffed.
    const comment: StableId = { kind: "comment", target: orioledb };
    const fb = buildFactBase(
      [ext("orioledb", "extensions"), { id: comment, payload: { text: "x" } }],
      [],
    );
    const view = resolveView(fb, supabasePolicy);
    expect(view.isReferenceOnly(orioledb)).toBe(true);
    expect(view.get(comment)).toBeUndefined();
  });

  test("projects out pg_graphql but keeps a user extension", () => {
    const fb = buildFactBase(
      [ext("pg_graphql", "graphql"), ext("pg_trgm", "extensions")],
      [],
    );
    const view = resolveView(fb, supabasePolicy);
    // platform-managed → invisible → never dropped (the #5555 fix)
    expect(view.get(pgGraphql)).toBeUndefined();
    // user-declarable → still managed
    expect(view.get(pgTrgm)).toBeDefined();
  });

  test("projects out the wrappers extension (dashboard-installed, CLI-1470)", () => {
    // `wrappers` is installed by the dashboard when the user enables a wrapper
    // integration, so it is never declared in user schema files. Keeping it
    // managed would plan `DROP EXTENSION "wrappers"` on every diff against a
    // project with an integration enabled — and with the wrappers-provisioned
    // FDWs projected out (Rule 6c), that drop is not even appliable: the
    // suppressed FDW's handler/validator dependencies block a bare DROP
    // EXTENSION (PR #401 review, P1).
    const fb = buildFactBase([ext("wrappers", "extensions")], []);
    const view = resolveView(fb, supabasePolicy);
    expect(view.get(wrappers)).toBeUndefined();
  });
});

describe("supabase policy — grants on extension members in `extensions`", () => {
  const extensions: StableId = { kind: "schema", name: "extensions" };
  const net: StableId = { kind: "schema", name: "net" };
  const fn = (schema: string, name: string): StableId => ({
    kind: "function",
    schema,
    name,
    args: ["text"],
  });
  const similarity = fn("extensions", "similarity");
  const statementsReset = fn("extensions", "pg_stat_statements_reset");
  const cronAccess = fn("extensions", "grant_pg_cron_access");
  const httpGet = fn("net", "http_get");

  const keptGrantees = (grants: [StableId, string][]): string[] => {
    const fb = buildFactBase(
      [
        { id: extensions, payload: {} },
        { id: net, payload: {} },
        ext("pg_trgm", "extensions"),
        ext("pg_stat_statements", "extensions"),
        ext("pg_net", "extensions"),
        { id: similarity, parent: extensions, payload: {} },
        { id: statementsReset, parent: extensions, payload: {} },
        { id: cronAccess, parent: extensions, payload: {} },
        { id: httpGet, parent: net, payload: {} },
        ...grants.map(
          ([target, grantee]): Fact => ({
            id: { kind: "acl", target, grantee },
            parent: target,
            payload: { privileges: ["EXECUTE"], grantable: [] },
          }),
        ),
      ],
      [
        { from: similarity, to: pgTrgm, kind: "memberOfExtension" },
        {
          from: statementsReset,
          to: { kind: "extension", name: "pg_stat_statements" },
          kind: "memberOfExtension",
        },
        {
          from: httpGet,
          to: { kind: "extension", name: "pg_net" },
          kind: "memberOfExtension",
        },
      ],
    );
    return resolveView(fb, supabasePolicy)
      .facts()
      .flatMap((f) => (f.id.kind === "acl" ? [f.id.grantee] : []))
      .sort();
  };

  test("keeps user grants on a pg_trgm member, not the platform's", () => {
    expect(
      keptGrantees([
        [similarity, "authenticated"],
        [similarity, "app_reader"],
        [similarity, "postgres"],
        [similarity, "dashboard_user"],
        [similarity, "PUBLIC"],
      ]),
    ).toEqual(["app_reader", "authenticated"]);
  });

  test("still excludes platform-extension members, helpers and other system schemas", () => {
    expect(
      keptGrantees([
        [statementsReset, "authenticated"],
        [cronAccess, "authenticated"],
        [httpGet, "authenticated"],
      ]),
    ).toEqual([]);
  });
});
